Welcome to the ultimate movie database program. 

1.To get started, ensure that the program is unzipped. 

2.Also ensure that python is installed along with the latest version of pip.

3.Lastly, run the "MovieDatabaseProject.exe - Shortcut" executable. 