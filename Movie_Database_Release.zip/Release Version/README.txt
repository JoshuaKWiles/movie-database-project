Welcome to the ultimate movie database. To begin, perform the following steps.

1. Unzip program folder

2. Ensure python (at least 3.10) is installed along with the latest version of pip

3. Also ensure latest version of microsoft edge is installed

4. To ensure python compatability, navigate to the "Movie Database\scraper" folder in cmd, and run the command "python main.py", this installs any lingering libraries prior to execution. 

5. Finally, run the "MovieDatabaseProject.exe" file. 